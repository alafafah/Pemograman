<?php
session_start();
error_reporting(0);
set_time_limit(0);
ignore_user_abort(1);
require_once('lib/fungsi.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Get Cookie </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 
<div class="container">
<center><h2>Get Cookie & Useragent </h2>
<div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">100% Work</div>
                    <div class="panel-body">
                        <form role="form" method="post">
                            <fieldset>
							                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="username" type="text" value="">
                                </div>
							                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <button type="submit" name="submit" class="btn btn-success btn-block">Login</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div></center>
<? 	if(!$_POST['username']||!$_POST['password']){ }else{
		$ua = generate_useragent();
		$devid = generate_device_id();
		$login = proccess(1, $ua, 'accounts/login/', 0, hook('{"device_id":"'.$devid.'","guid":"'.generate_guid().'","username":"'.trim($_POST['username']).'","password":"'.($_POST['password']).'","Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"}'));
		$data = json_decode($login[1]);
		if($data->status<>ok)
			print '<div class="alert alert-warning">
                                Username/Password Salah!
                            </div>';
		else{
			preg_match_all('%Set-Cookie: (.*?);%',$login[0],$d);$cookie = '';
			for($o=0;$o<count($d[0]);$o++)$cookie.=$d[1][$o].";";
			$_SESSION['data'] = array('cookies' => $cookie, 'useragent' => $ua, 'device_id' => $devid, 'username' => $data->logged_in_user->username, 'id' => $data->logged_in_user->pk);
			print 'Cookies </br><pre>'.$cookie.'</pre>Useragent </br><pre>'.$ua.'</pre> ';
		}
} ?>
<br><li> Masukkan Cookie Ke <a href="cookie.php"> SINI </a>
<br><li> Masukkan Useragent Ke <a href="useragent.php"> SINI </a>
</div>
</body>
</html>