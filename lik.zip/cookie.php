<html>
<head>
<title>Cookie </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<?php
error_reporting(0);
if($_GET[vip] == 'cookie'){
die('<h1>SUCCESS</h1> 
User <a href="useragent.php">Lanjut Masukkin Useragent</a>');
}
function back($url){
print '<meta http-equiv="refresh" content="0;url='.$url.'" />';
}
session_start();
if($_POST[pw]){
$pw = 'ALafafah';
if($_POST[pw] == $pw){
if($_POST[cookie]){
	if(preg_match("'access_token=(.*?)&expires_in='", $_POST[cookie], $matches)){
	$a_cookie = $matches[1];
		}else{
	$a_cookie = $_POST[cookie];}
$bg=fopen('cookie.txt','w');
fwrite($bg,$a_cookie);
fclose($bg);
back('cookie.php?vip=cookie');
}else{
echo '<center>
<div class="container">
<h3>Silahkan Input Cookie Anda</h3></br>
<div class="panel-group">
<div class="panel panel-primary">
    <div class="panel-heading">Cookie</div></br>
      <div class="panel-body">
        <fieldset>
            <form action="cookie.php" method="POST">
            <input class="form-control" placeholder="Cookie" type="text" name="cookie" style="width:100%">
            <input type="hidden" name="pw" value="'.$_POST[pw].'"></br>
            <input class="btn btn-success btn-block" type="submit" value="Submit Cookie" >
        </fieldset>
    </form>
</div>
';
}
}else{
echo 'Mau Maling ya?cie <a href="cookie.php">kembali</a>';
}
}else{
echo '<center>
<div class="container">
<h1>Silahkan Masukkan Password</h1><br>
<div class="panel-group">
<div class="panel panel-primary">
    <div class="panel-heading">Password</div>
      <div class="panel-body">
        <fieldset>
            <form action="cookie.php" method="POST">
            <div class="form-group">
            <input class="form-control" placeholder="Password" type="password" name="pw"/><br>
            <input class="btn btn-success btn-block" type="submit" value="Login"/>
        </fieldset>
    </form>
</div>
</center>';
}
?>
</body></html><noscript>