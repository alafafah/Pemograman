<?php
$fa['cookies'] = file_get_contents('cookie.txt'); // Your Cookies Here
$fa['useragent'] = file_get_contents('useragent.txt'); // Your Uzseragent Here
?>