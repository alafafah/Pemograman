<?php
set_time_limit(0);
ignore_user_abort(1);
require_once('lib/fungsi.php');
require_once('baseconfig.php');

		$req = proccess(1, $fa['useragent'], 'feed/timeline/', $fa['cookies'], null, array('Accept-Language: id-ID, en-US', 'X-IG-Connection-Type: WIFI'));
		$req = json_decode($req[1]);
		$jumlahtl = count($req->items);
		for($i=0;$i<$jumlahtl;$i++):
			if(!$req->items[$i]->has_liked):
				proccess(1, $fa['useragent'], 'media/'.$req->items[$i]->id.'/like/', $fa['cookies'], hook('{"media_id":"'.$req->items[$i]->id.'"}'), array('Accept-Language: id-ID, en-US', 'X-IG-Connection-Type: WIFI'));
				print ' Sukses Di Like '.$req->items[$i]->id.' <br>';
				$fap = fopen('log.php', 'a');
				fwrite($fap, ''.$req->items[$i]->id.' Sukses <br>');
				fclose($fap);
				flush();
			endif;
		endfor;
?>