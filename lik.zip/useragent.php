<html>
<head>
<title>Useragent </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<?php
error_reporting(0);
if($_GET[vip] == 'useragent'){
die('<center><h1>SUCCESS</h1>
User <a href="like.php">Tes Like</a>');
}
function back($url){
print '<meta http-equiv="refresh" content="0;url='.$url.'" />';
}
session_start();
if($_POST[pw]){
$pw = 'ALafafah';
if($_POST[pw] == $pw){
if($_POST[useragent]){
	if(preg_match("'access_token=(.*?)&expires_in='", $_POST[useragent], $matches)){
	$a_useragent = $matches[1];
		}else{
	$a_useragent = $_POST[useragent];}
$bg=fopen('useragent.txt','w');
fwrite($bg,$a_useragent);
fclose($bg);
back('useragent.php?vip=useragent');
}else{
echo '<center>
<div class="container">
<h3>Silahkan Input Useragent Anda</h3></br>
<div class="panel-group">
<div class="panel panel-primary">
    <div class="panel-heading">Useragent</div></br>
      <div class="panel-body">
        <fieldset>
            <form action="useragent.php" method="POST">
            <input class="form-control" placeholder="Useragent" type="text" name="useragent" style="width:100%">
            <input type="hidden" name="pw" value="'.$_POST[pw].'"></br>
            <input class="btn btn-success btn-block" type="submit" value="Submit Useragent" >
        </fieldset>
    </form>
</div>
';
}
}else{
echo 'Mau Maling ya?cie <a href="useragent.php">kembali</a>';
}
}else{
echo '<center>
<div class="container">
<h1>Silahkan Masukkan Password</h1><br>
<div class="panel-group">
<div class="panel panel-primary">
    <div class="panel-heading">Password</div>
      <div class="panel-body">
        <fieldset>
            <form action="useragent.php" method="POST">
            <div class="form-group">
            <input class="form-control" placeholder="Password" type="password" name="pw"/><br>
            <input class="btn btn-success btn-block" type="submit" value="Login"/>
        </fieldset>
    </form>
</div>
</center>';
}
?>
</body></html><noscript>